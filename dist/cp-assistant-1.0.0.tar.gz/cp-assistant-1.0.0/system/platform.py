import platform


def get_platform():
    return platform.system()
