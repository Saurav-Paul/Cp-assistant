bye = [
    'bye', 'tata', 'exit', 'quit', 'stop',
]
